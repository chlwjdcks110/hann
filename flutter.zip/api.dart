class API {
  static const hostConnect = "http://192.168.219.102:8080";
  static const hostConnectUSer = "$hostConnect/user";

  static const signup = "$hostConnect/user/signup.php";
  static const validateEmail = "$hostConnect/user/validate_email.php";
}